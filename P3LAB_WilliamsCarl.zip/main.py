

  
mport java.util.Scanner;


public class Test
{
public static void main(String []args)
{
int year;
System.out.print("Enter a year : ");
Scanner sc=new Scanner(System.in);
year=sc.nextInt();
boolean isLeapYear=((year%4==0)&&(year%100)!=0 || year%400==0);
System.out.println("Is "+year+" a leap year? "+isLeapYear);
}
}